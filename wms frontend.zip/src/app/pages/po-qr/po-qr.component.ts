import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import * as QRCode from 'qrcode';
import { PurchaseOrderService, PurchaseOrderDto } from '../../services/purchase-order.service';
import { QrService } from '../../services/qr.service';

interface POItem {
  id: number;
  poNumber: string;
  supplierName: string;
  description: string;
  boxNumber: string;
  serialNumber: string;
  quantity: number;
  poItemId: number | null; // needed by Generate QR / Receiving further down the flow
}

@Component({
  selector: 'app-po-qr',
  standalone: false,
  templateUrl: './po-qr.component.html',
  styleUrl: './po-qr.component.css'
})
export class POQRComponent implements OnInit {

  // ---- search field ----
  searchTerm = '';

  // ---- real Supplier POs, pulled from WMS (which mirrors VISIPACK) ----
  qrData: POItem[] = [];
  loading = false;
  syncing = false;
  loadError = '';

  // ---- Create PO modal kept for legacy/manual testing only. POs are meant
  // to come from VISIPACK via "Sync from VISIPACK" above, not typed in here. ----
  showCreatePOModal = false;
  poForm: FormGroup;

  // ---- QR modal state ----
  showQrModal = false;
  selectedItem: POItem | null = null;
  qrDataUrl: string | null = null;
  generating = false;
  generateError = '';

  private serialCounter = 5;

  constructor(
    private fb: FormBuilder,
    private poService: PurchaseOrderService,
    private qrService: QrService
  ) {
    this.poForm = this.fb.group({
      poNumber: ['', Validators.required],
      supplierName: ['', Validators.required],
      description: ['', Validators.required],
      boxNumber: ['', Validators.required],
      quantity: [1, [Validators.required, Validators.min(1)]]
    });
  }

  ngOnInit(): void {
    this.loadPOs();
  }

  // Flatten a PO + its line items into the flat row shape this screen's
  // table/template already expects (one row per PO line item).
  private toRows(pos: PurchaseOrderDto[]): POItem[] {
    const rows: POItem[] = [];
    let idx = 1;
    for (const po of pos) {
      for (const item of po.items) {
        rows.push({
          id: idx++,
          poNumber: po.poNumber,
          supplierName: po.supplierName,
          description: item.itemName,
          boxNumber: item.itemCode,
          serialNumber: `${po.poNumber}-${item.itemCode}`,
          quantity: item.orderedQty,
          poItemId: item.poItemId
        });
      }
    }
    return rows;
  }

  loadPOs(): void {
    this.loading = true;
    this.loadError = '';
    this.poService.list().subscribe({
      next: (res) => {
        this.qrData = this.toRows(res.data || []);
        this.loading = false;
      },
      error: (err) => {
        this.loadError = err?.error?.message || 'Failed to load purchase orders';
        this.loading = false;
      }
    });
  }

  // Step 1-3: pull the latest Approved Supplier POs from VISIPACK, then reload.
  syncPOs(): void {
    this.syncing = true;
    this.loadError = '';
    this.poService.syncFromVisipack().subscribe({
      next: () => {
        this.syncing = false;
        this.loadPOs();
      },
      error: (err) => {
        this.syncing = false;
        this.loadError = err?.error?.message || 'Sync with VISIPACK failed';
      }
    });
  }

  // ---- search ----
  get filteredData(): POItem[] {
    const term = this.searchTerm.trim().toLowerCase();
    if (!term) return this.qrData;
    return this.qrData.filter(item =>
      item.poNumber.toLowerCase().includes(term) ||
      item.supplierName.toLowerCase().includes(term) ||
      item.description.toLowerCase().includes(term) ||
      item.boxNumber.toLowerCase().includes(term)
    );
  }

  // ---- Create PO Modal (legacy, local-only, not persisted to WMS) ----
  openCreatePOModal() {
    this.showCreatePOModal = true;
    this.poForm.reset({ poNumber: '', supplierName: '', description: '', boxNumber: '', quantity: 1 });
  }

  closeCreatePOModal() {
    this.showCreatePOModal = false;
  }

  saveNewPO() {
    if (this.poForm.invalid) {
      this.poForm.markAllAsTouched();
      return;
    }
    const { poNumber, supplierName, description, boxNumber, quantity } = this.poForm.value;
    this.qrData.unshift({
      id: this.qrData.length + 1,
      poNumber, supplierName, description, boxNumber,
      serialNumber: `SN${String(this.serialCounter).padStart(3, '0')}`,
      quantity,
      poItemId: null
    });
    this.serialCounter++;
    this.closeCreatePOModal();
    alert('Added locally for testing only — this PO does not exist in WMS/VISIPACK. Use "Sync from VISIPACK" for real POs.');
  }

  // ---- QR modal ----
  openQrModal(item: POItem) {
    this.selectedItem = item;
    this.qrDataUrl = null;
    this.generating = false;
    this.generateError = '';
    this.showQrModal = true;
  }

  closeQrModal() {
    this.showQrModal = false;
    this.selectedItem = null;
    this.qrDataUrl = null;
    this.generating = false;
  }

  // "Generate QR" — now calls the real WMS API (POST /qr-transactions), which
  // creates a row in qr_transactions, instead of just encoding JSON client-side.
  async generateQr() {
    if (!this.selectedItem) return;
    this.generating = true;
    this.generateError = '';

    this.qrService.generate(this.selectedItem.poNumber).subscribe({
      next: async (res) => {
        try {
          this.qrDataUrl = await QRCode.toDataURL(res.data.qrCode, { width: 300, margin: 2 });
        } catch (err) {
          console.error('QR image render failed', err);
        } finally {
          this.generating = false;
        }
      },
      error: (err) => {
        this.generateError = err?.error?.message || 'Failed to generate QR code';
        this.generating = false;
      }
    });
  }

  downloadQr() {
    if (!this.qrDataUrl) return;
    const link = document.createElement('a');
    link.href = this.qrDataUrl;
    link.download = `${this.selectedItem?.poNumber}_${this.selectedItem?.serialNumber}.png`;
    link.click();
  }

  printQr() {
    if (!this.qrDataUrl || !this.selectedItem) return;
    const printWindow = window.open('', '_blank', 'width=600,height=600');
    if (!printWindow) {
      alert('Please allow popups for this site');
      return;
    }
    const item = this.selectedItem;
    printWindow.document.write(`
      <!DOCTYPE html>
      <html>
        <head>
          <title>QR Code - ${item.poNumber}</title>
          <style>
            body { display:flex; flex-direction:column; align-items:center; justify-content:center; height:100vh; margin:0; font-family:Arial, sans-serif; background:#f5f7fa; }
            .qr-container { text-align:center; padding:40px; background:white; border-radius:12px; box-shadow:0 4px 20px rgba(0,0,0,0.1); max-width:500px; }
            .qr-image { max-width:300px; height:auto; margin-bottom:20px; }
            .qr-details { margin-top:20px; font-size:14px; color:#374151; text-align:left; padding:0 20px; }
            .qr-details p { margin:8px 0; padding:5px 0; border-bottom:1px solid #f0f0f0; }
            .qr-details p:last-child { border-bottom:none; }
            .qr-details strong { color:#1f2937; display:inline-block; width:140px; }
            .title { font-size:20px; font-weight:600; color:#0f766e; margin-bottom:20px; }
            @media print { .no-print { display:none; } .qr-container { box-shadow:none; border:1px solid #e5e7eb; } }
          </style>
        </head>
        <body>
          <div class="qr-container">
            <div class="title">PO QR Code</div>
            <img src="${this.qrDataUrl}" alt="QR Code" class="qr-image" />
            <div class="qr-details">
              <p><strong>PO Number:</strong> ${item.poNumber}</p>
              <p><strong>Supplier:</strong> ${item.supplierName}</p>
              <p><strong>Description:</strong> ${item.description}</p>
              <p><strong>Item Code:</strong> ${item.boxNumber}</p>
              <p><strong>Ordered Qty:</strong> ${item.quantity}</p>
            </div>
            <button onclick="window.print()" class="no-print" style="margin-top:25px; padding:12px 30px; background:#0f766e; color:white; border:none; border-radius:6px; cursor:pointer; font-size:14px; font-weight:500;">
              🖨️ Print QR Code
            </button>
          </div>
        </body>
      </html>
    `);
    printWindow.document.close();
  }
}
