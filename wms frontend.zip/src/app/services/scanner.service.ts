import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { AppSettings } from '../app.settings';

@Injectable({ providedIn: 'root' })
export class ScannerService {
  constructor(private http: HttpClient) {}

  // "Scan QR" — validates the code against qr_transactions and logs the
  // attempt in scanner_transactions either way (success or failure).
  scan(code: string): Observable<{ success: boolean; data: { qrCode: string; poNumber: string; poId: number; status: string } }> {
    return this.http.post<any>(AppSettings.API.scan, { code });
  }
}
