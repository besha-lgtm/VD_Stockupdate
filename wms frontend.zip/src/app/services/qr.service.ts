import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { AppSettings } from '../app.settings';

@Injectable({ providedIn: 'root' })
export class QrService {
  constructor(private http: HttpClient) {}

  // "Generate QR" — registers a real QR against a PO in the WMS database
  // (qr_transactions table), unlike the old client-side-only QR image.
  generate(poNumber: string): Observable<{ success: boolean; data: { qrCode: string; poNumber: string; supplierName: string } }> {
    return this.http.post<any>(AppSettings.API.qrTransactions, { poNumber });
  }

  get(qrCode: string): Observable<any> {
    return this.http.get<any>(`${AppSettings.API.qrTransactions}/${qrCode}`);
  }
}
